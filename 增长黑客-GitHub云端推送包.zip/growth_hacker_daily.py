#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
《增长黑客》90天书摘 · 云端定时群推送（GitHub Actions 版）

- 每天北京时间 17:00 把当天那段约800字的原文摘抄发到飞书群
- 消息内容 = 摘抄正文本身，不带书名、第几天、日期、来源或任何多余文字
- 完全运行在 GitHub 服务器上，本地电脑关机照常发送
- 内置幂等：同一天重复触发（多个 cron 时间点 / 手动重跑）只发一条
- 状态写在 gh_push_state.json 并由 workflow 提交回仓库

依赖：仅标准库
"""
import json
import os
import pathlib
import sys
import time
import urllib.request
import datetime

BASE = pathlib.Path(__file__).resolve().parent
QUOTES_FILE = BASE / "quotes_800.json"
STATE_FILE = BASE / "gh_push_state.json"

# 优先用仓库 Secret；没有则退回内置 webhook（与既有推送同一通道）
WEBHOOK = os.environ.get("FEISHU_WEBHOOK_URL") or (
    "https://open.feishu.cn/open-apis/bot/v2/hook/96b64c23-c5d4-4c82-adad-da5ddf2dd7be"
)

START_DATE = "2026-10-14"   # 第1天
END_DATE = "2027-01-11"     # 第90天
MAX_RETRY = 3

# 90 天推送完毕后，只发一次的收官提醒
COMPLETION_TEXT = "《增长黑客》90 天书摘已全部推送完毕（共 90 天）。"
COMPLETION_FLAG = "__completed_notified__"


def bj_today():
    """北京时间当天日期"""
    now_utc = datetime.datetime.now(datetime.timezone.utc)
    return (now_utc + datetime.timedelta(hours=8)).date().isoformat()


def load_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def save_state(state):
    try:
        with open(STATE_FILE, "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False, indent=1)
    except Exception as e:
        print(f"[WARN] 状态写入失败: {e}")


def find_today_text(today):
    data = load_json(QUOTES_FILE, None)
    if not data:
        return None, None
    for d in data.get("days", []):
        if d.get("date") == today:
            return (d.get("text") or "").strip(), d.get("day")
    return None, None


def webhook_send(text):
    body = json.dumps({"msg_type": "text", "content": {"text": text}},
                      ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        WEBHOOK, data=body,
        headers={"Content-Type": "application/json; charset=utf-8"},
        method="POST")
    with urllib.request.urlopen(req, timeout=30) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    code = data.get("code", data.get("StatusCode"))
    return (code == 0), data


def main():
    today = bj_today()
    # 支持手动补发：python growth_hacker_daily.py --date 2026-10-14
    argv = sys.argv[1:]
    if "--date" in argv:
        i = argv.index("--date")
        if i + 1 < len(argv) and argv[i + 1].strip():
            today = argv[i + 1].strip()
    force = "--force" in argv
    dry = "--dry-run" in argv

    state = load_json(STATE_FILE, {}) or {}
    sent = state.get("sent", {})

    print(f"[info] 目标日期: {today}")

    if not (START_DATE <= today <= END_DATE):
        print(f"[SKIP] {today} 不在任务区间 {START_DATE} ~ {END_DATE}")
        return 0

    if sent.get(today) and not force:
        print(f"[SKIP] {today} 已推送过（{sent[today]}），不重复发送")
        return 0

    text, day = find_today_text(today)
    if not text:
        print(f"[SKIP] 内容文件中没有 {today} 的摘抄")
        return 0

    # 兜底：正文里若混入标题/日期行，去掉（正常情况不会出现）
    lines = [ln for ln in text.split("\n") if ln.strip()]
    lines = [ln for ln in lines if not ln.strip().startswith("📖")]
    lines = [ln for ln in lines if ln.strip() != today]
    message = "\n".join(lines).strip()

    print(f"[info] 第{day}天，正文 {len(message)} 字")

    if dry:
        print("[DRY-RUN] 只预览，不发送。消息内容如下：")
        print("-" * 40)
        print(message)
        print("-" * 40)
        return 0

    last_err = None
    for attempt in range(1, MAX_RETRY + 1):
        try:
            ok, info = webhook_send(message)
            if ok:
                sent[today] = datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")
                state["sent"] = sent
                print(f"[OK] 已推送 {today} → 飞书群 ({len(message)}字)")
                # 第90天：正文发完后，追加一条且仅一条收官提醒
                if today == END_DATE and not state.get(COMPLETION_FLAG):
                    try:
                        ok2, info2 = webhook_send(COMPLETION_TEXT)
                        if ok2:
                            state[COMPLETION_FLAG] = datetime.datetime.now(
                                datetime.timezone.utc).isoformat(timespec="seconds")
                            print(f"[OK] 已发送 90 天收官提醒（仅此一次）")
                        else:
                            print(f"[WARN] 收官提醒未成功: {json.dumps(info2, ensure_ascii=False)[:200]}")
                    except Exception as e:
                        print(f"[WARN] 收官提醒异常: {str(e)[:200]}")
                save_state(state)
                return 0
            last_err = info
            print(f"[WARN] 第{attempt}次发送未成功: {json.dumps(info, ensure_ascii=False)[:200]}")
        except Exception as e:
            last_err = str(e)
            print(f"[WARN] 第{attempt}次发送异常: {str(e)[:200]}")
        if attempt < MAX_RETRY:
            time.sleep(5 * attempt)

    print(f"[FAIL] 发送失败: {json.dumps(last_err, ensure_ascii=False)[:300] if not isinstance(last_err,str) else last_err}")
    return 1


if __name__ == "__main__":
    sys.exit(main())
