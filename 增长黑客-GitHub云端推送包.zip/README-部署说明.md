# 《增长黑客》90天书摘 · 云端定时群推送（GitHub Actions）

**装好之后，你的电脑关机、关 Wi-Fi，每天 17:00 也照常把当天那段约 800 字的原文摘抄发到飞书群。**

- 目标群：「读书打卡-每日17点推送」（`oc_fa10eab4e1ba6f9358eb4383d37cda10`）
- 推送时间：每天北京时间 **17:00**（另有 18:30 兜底补发）
- 内容：`quotes_800.json`，90 天每天 812~900 字，**全部是《增长黑客》原书原文**
- 消息格式：**只有正文本身**，不带书名、第几天、日期、来源或任何多余文字
- **任务周期：2026-10-14 ~ 2027-01-11（共 90 天，第 1 天 = 2026-10-14）**
- **第 90 天推送完之后，会额外发一条收官提醒（只发一次）**：
  「《增长黑客》90 天书摘已全部推送完毕（共 90 天）。」
  之后日期自动落到区间外，脚本会静默跳过，不再发送任何内容。

## 包内文件

| 文件 | 作用 |
|---|---|
| `.github/workflows/growth-hacker-daily.yml` | **现行**定时任务（每天 17:00 + 18:30 兜底） |
| `.github/workflows/daily_excerpt.yml` | **停用旧任务**：覆盖仓库里原来的同名文件即可停掉《从零开始做运营》的刷屏 |
| `growth_hacker_daily.py` | 发送脚本：按北京时间取当天内容 → 发 webhook；第 90 天追加收官提醒 |
| `quotes_800.json` | 90 天内容（原文，约800字/天） |
| `gh_push_state.json` | 发送状态，防止同一天重复发送（由 action 自动提交） |

## 部署步骤（约 2 分钟）

前提：你已经有一个设置了 `FEISHU_WEBHOOK_URL` 密钥的仓库
（即 `liukewei6kv/feishu-daily-excerpt`，密钥已存在，**不用新建**）。

1. 打开仓库首页 → **Add file** → **Upload files**
2. 把本文件夹里**所有内容**一起拖进上传区：
   - `.github/workflows/growth-hacker-daily.yml`
   - `.github/workflows/daily_excerpt.yml`  ← **这个用来覆盖旧的刷屏任务**
   - `growth_hacker_daily.py`、`quotes_800.json`、`gh_push_state.json`、`README-部署说明.md`
   - 如果拖隐藏文件夹不方便：用 **Add file → Create new file**，文件名直接填
     `.github/workflows/growth-hacker-daily.yml`（GitHub 会自动建目录），把内容粘进去；
     再用 **Add file → Upload files** 传其余文件
   - ⚠️ 提示覆盖时选**覆盖**
3. 页面下方点绿色 **Commit changes**
4. 点仓库顶部 **Actions** 标签：
   - 左侧应出现 **Growth Hacker Daily Quote**
   - 原来的 **daily-excerpt** 应已消失（被同名文件覆盖）
5. 第一次先手动跑一遍验证：**Growth Hacker Daily Quote** → 右侧 **Run workflow** → 绿色按钮
   - 跑完看日志，出现 `[OK] 已推送 2026-10-14 → 飞书群` 就说明通了

> 同一天只会发一条：17:00 和 18:30 两次触发中，第一次成功后第二次会自动跳过。

## 常用操作

| 想做的事 | 怎么做 |
|---|---|
| 手动补发某一天 | Actions → Growth Hacker Daily Quote → Run workflow → date 填 `2026-10-25` |
| 重新发送某天（已发过也强制发） | 本地跑 `python growth_hacker_daily.py --date 2026-10-25 --force` |
| 先预览不发送 | 本地跑 `python growth_hacker_daily.py --date 2026-10-25 --dry-run` |
| 彻底停止整个任务 | Actions → 左侧选中 Growth Hacker Daily Quote → 右上 `···` → Disable workflow |
| 改内容 | 改 `quotes_800.json` 后提交即可（日期是索引键，不要改动日期字段） |

## 说明

- 脚本只用 Python 标准库，不需要 pip 安装任何东西。
- 推送走飞书**群自定义机器人 webhook**，不依赖应用机器人入群，也不依赖任何用户授权，因此不会因为授权过期而中断。
- 内置幂等：`gh_push_state.json` 记录已发送日期，17:00 与 18:30 两次触发只会发一条。
- 收官提醒同样带幂等标记（`__completed_notified__`），**同一天不会重复发**。
- GitHub 的定时任务偶尔会排队延迟几分钟到十几分钟，属正常现象；18:30 那次兜底能覆盖失败情况。
- 周期外日期（早于 2026-10-14 或晚于 2027-01-11）会自动跳过，不会误发。
